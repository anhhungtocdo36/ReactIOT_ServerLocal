#ifndef _CONFIG_H_
#define _CONFIG_H_
#include "stddef.h"
#include <FS.h>

class ESPConfig {
public:
  ESPConfig(FS& fs, const char* filename);
  bool load();
  bool set(String key, String value);
  String get(String key);
  bool save();
protected:
  String _filename;
  FS _fs;
};
#endif

