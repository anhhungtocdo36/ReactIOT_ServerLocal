#ifndef _APP_H_
#define _APP_H_

void app_setup();
void app_loop();

#endif