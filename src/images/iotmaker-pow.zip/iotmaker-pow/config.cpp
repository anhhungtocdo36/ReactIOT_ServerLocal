/*
* @Author: TuanPM
* @Date:   2017-03-04 21:02:49
* @Last Modified by:   TuanPM
* @Last Modified time: 2017-03-04 21:54:01
*/
#include <ArduinoJson.h>
#include "config.h"

ESPConfig::ESPConfig(FS& fs, const char* filename): _fs(fs), _filename(String(filename))
{

}

bool ESPConfig::load()
{
	    File configFile = _fs.open(_filename, "r");
	    if (!configFile) {
	        // DEBUGLOG("Failed to open config file");
	        return false;
	    }

	    size_t size = configFile.size();
	    if (size > 1024) {
	        // DEBUGLOG("Config file size is too large");
	        configFile.close();
	        return false;
	    }

	    // Allocate a buffer to store contents of the file.
	    std::unique_ptr<char[]> buf(new char[size]);

	    // We don't use String here because ArduinoJson library requires the input
	    // buffer to be mutable. If you don't use ArduinoJson, you may as well
	    // use configFile.readString instead.
	    configFile.readBytes(buf.get(), size);
	    configFile.close();
	    // DEBUGLOG("JSON file size: %d bytes\r\n", size);
	    DynamicJsonBuffer jsonBuffer(1024);
	    //StaticJsonBuffer<1024> jsonBuffer;
	    JsonObject& json = jsonBuffer.parseObject(buf.get());

	    if (!json.success()) {
	        // DEBUGLOG("Failed to parse config file\r\n");
	        return false;
	    }
	#ifndef RELEASE
	    String temp;
	    json.prettyPrintTo(temp);
	    Serial.println(temp);
	#endif

	    // _config.ssid = json["ssid"].as<const char *>();

	    // _config.password = json["pass"].as<const char *>();

	    // _config.ip = IPAddress(json["ip"][0], json["ip"][1], json["ip"][2], json["ip"][3]);
	    // _config.netmask = IPAddress(json["netmask"][0], json["netmask"][1], json["netmask"][2], json["netmask"][3]);
	    // _config.gateway = IPAddress(json["gateway"][0], json["gateway"][1], json["gateway"][2], json["gateway"][3]);
	    // _config.dns = IPAddress(json["dns"][0], json["dns"][1], json["dns"][2], json["dns"][3]);

	    // _config.dhcp = json["dhcp"].as<bool>();

	    // _config.ntpServerName = json["ntp"].as<const char *>();
	    // _config.updateNTPTimeEvery = json["NTPperiod"].as<long>();
	    // _config.timezone = json["timeZone"].as<long>();
	    // _config.daylight = json["daylight"].as<long>();
	    // _config.deviceName = json["deviceName"].as<const char *>();

	    // //config.connectionLed = json["led"];

	    // DEBUGLOG("Data initialized.\r\n");
	    // DEBUGLOG("SSID: %s ", _config.ssid.c_str());
	    // DEBUGLOG("PASS: %s\r\n", _config.password.c_str());
	    // DEBUGLOG("NTP Server: %s\r\n", _config.ntpServerName.c_str());
	    // //DEBUGLOG("Connection LED: %d\n", config.connectionLed);
	    // DEBUGLOG(__PRETTY_FUNCTION__);
	    // DEBUGLOG("\r\n");
    return true;
}

bool ESPConfig::set(String key, String value)
{
    return true;
}

String ESPConfig::get(String key)
{
    return key;
}

bool ESPConfig::save()
{
    return true;
}