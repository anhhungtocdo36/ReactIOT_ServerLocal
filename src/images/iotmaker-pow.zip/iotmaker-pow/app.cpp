#include <ESP8266WiFi.h>
#include <ESP8266mDNS.h>
#include <ArduinoOTA.h>
#include <FS.h>
#include <Hash.h>
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <AsyncJson.h>
#include <ArduinoJson.h>
#include <HLW8012.h>
#include "app.h"
#include "config.h"
#include "handle.h"

AsyncWebServer server(80);// Instantiate the webserver object
AsyncWebSocket ws("/ws");//Server methods dùng websocket
AsyncEventSource events("/events"); // setup server includes EventSource (Server-Sent Events) plugin
// được sử dụng để gửi những short text event đến web browser.
// Sự khác biệt giữa EventSource và WebSockets là EventSource chỉ theo 1 hướng duy nhất từ server và giao thức chỉ là dạng test.

ESPConfig CFG(SPIFFS, "/config.json");
/* THÔNG TIN
 * class ESPConfig ở file config.h bao gồm một số thao tác với file
 * FUNCTION : ESPConfig(FS& fs, const char* filename);
 * CÁC HÀM CON
 *		load()
 *			CHỨC NĂNG : Mở file để đọc  S
 *			LỆNH : File configFile = _fs.open(_filename, "r");
 *			CHI TIẾT :
 *					Nếu kích thước file > 1 Mb thì đóng file, trả về false.
 *					Cấp phát a buffer để lưu trữ nội dung file
 *get
 *set
 *save
*/
AppHandle handle;

void onWsEvent(AsyncWebSocket * server, AsyncWebSocketClient * client, AwsEventType type, void * arg, uint8_t *data, size_t len) {

	handle.processWS(server, client, type, arg, data, len);
}

void app_setup()
{
	Serial.begin(115200);
	SPIFFS.begin();
	CFG.load();

	WiFi.hostname("hostname"); //set tên AP cho ESP8266
	WiFi.mode(WIFI_AP_STA);
	WiFi.softAP("hostname"); // thiết lập 1 softAP để tạo 1 mạng WiFi
	WiFi.begin("IOTMAKER.VN", "@iotmaker.vn");
	// if(WiFi.waitForConnectResult() != WL_CONNECTED) {
	// 	Serial.printf("STA: Failed!\n");
	// 	WiFi.disconnect(false);
	// 	delay(1000);
	// 	WiFi.begin("ssid", "password");
	// }
	Serial.println(WiFi.localIP()); // In ra địa chi IP của STA 
	//Send OTA events to the browser

	ArduinoOTA.setHostname("hostName");
	ArduinoOTA.begin();

	MDNS.addService("http", "tcp", 80); // Để quảng bá DNS-SD services cần gọi MDNS.addService(service, protocol, port)
 // service và protocol thuộc format string


	server.serveStatic("/", SPIFFS, "/").setDefaultFile("index.html").setAuthentication("tuanpm1", "minhtuan1"); // Sử dụng thư viện webserver 
 //AsyncWebServer::serveStatic(const char* uri, fs::FS& fs, const char* path, const char* cache_control)
 
	// HTTP basic authentication
	server.on("/api", [](AsyncWebServerRequest * request) {
		if(!request->authenticate("tuanpm", "minhtuan"))
			return request->requestAuthentication();
		AsyncResponseStream *response = request->beginResponseStream("text/json");
		DynamicJsonBuffer jsonBuffer;
		JsonObject &root = jsonBuffer.createObject();
		root["heap"] = ESP.getFreeHeap();
		root["ssid"] = WiFi.SSID();
		root.printTo(*response);
		request->send(response);
	});
	ws.onEvent(onWsEvent);
	ws.setAuthentication("tuanpm1", "minhtuan1");
	events.setAuthentication("tuanpm1", "minhtuan1");
	server.addHandler(&ws);
	server.begin();

}

void app_loop()
{
	handle.processInterval(&ws);
	if(WiFi.status() == WL_CONNECTED) {
		ArduinoOTA.handle();
	}

}
