#ifndef _APPHANDLE_H_
#define _APPHANDLE_H_
#include "Arduino.h"
#include "stddef.h"
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>
//TODO
//add function
//handle.add(action, method, function);

class AppHandle {
public:
	AppHandle();
	void setup();
	String process(String msg);
	String process(String msg, std::function<void(String resp)> cb);
	void processWS(AsyncWebSocket * server, AsyncWebSocketClient * client, AwsEventType type, void * arg, uint8_t *data, size_t len);
	void processInterval(AsyncWebSocket * server);
protected:
	int _led;
	int _relay;
	bool _processing;
	String _invalid(std::function<void(String resp)> cb);
	String _ok(String action, String result, std::function<void(String resp)> cb);
};

#endif
