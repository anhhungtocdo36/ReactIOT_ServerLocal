#ifndef _APPPOWER_H_
#define _APPPOWER_H_
#include <Arduino.h>
#include "stddef.h"
class AppPOWER {
public:
	AppPOWER(){};
	String measure(std::function<void(String resp)> onComplete);
};
#endif