#ifndef _APPLOG_H_
#define _APPLOG_H_

#define DEBUG_ESP_IOT_APP
#ifdef DEBUG_ESP_IOT_APP
#ifdef DEBUG_ESP_PORT
#define LOG(...) DEBUG_ESP_PORT.printf( __VA_ARGS__ )
#endif
#endif

#ifndef LOG
#define LOG(...)
#endif

#endif