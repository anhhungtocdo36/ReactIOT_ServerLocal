/*
* @Author: TuanPM
* @Date:   2017-03-05 14:39:26
* @Last Modified by:   TuanPM
* @Last Modified time: 2017-03-05 20:56:18
*/
#include <ESP8266WiFi.h>
#include "wifi.h"
#include "log.h"

void _wifi_scan(int n)
{

}

String AppWIFI::scan(std::function<void(String resp)> onComplete)
{
	
	WiFi.scanNetworksAsync([onComplete](int n) {
		String resp = "[";
		if(n == WIFI_SCAN_FAILED) {
			LOG("no networks found");
		} else if(n) {
			LOG(" networks found");
			for(int i = 0; i < n; ++i)
			{
				if(resp != "[")
					resp += ",";
				resp += "{\"ssid\":\"" + WiFi.SSID(i) + "\", \"rssi\":" + WiFi.RSSI(i) + ", \"sec\":" + String(WiFi.encryptionType(i)) + "}";
			}
		}
		resp += "]";
		onComplete(resp);
	}, false);
	return "";
}
void AppWIFI::connect(String ssid, String pass)
{

}

