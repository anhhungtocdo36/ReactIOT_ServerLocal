/*
* @Author: TuanPM
* @Date:   2017-03-05 22:01:54
* @Last Modified by:   TuanPM
* @Last Modified time: 2017-03-05 22:56:10
*/
#include <ESP8266WiFi.h>
#include "power.h"

String AppPOWER::measure(std::function<void(String resp)> onComplete)
{
	String resp = "";
	resp += "{\"volt\":" + String(random(180, 230));
	resp += ",\"current\":" + String(random(10, 17));
	resp += ",\"power\":" + String(random(1000, 2000));
	resp += ",\"factor\":" + String(random(80, 100));
	resp += "}";
	if(onComplete)
		onComplete(resp);
	return resp;
}