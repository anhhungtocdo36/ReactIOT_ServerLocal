/*
* @Author: TuanPM
* @Date:   2017-03-04 23:52:40
* @Last Modified by:   Tuan PM
* @Last Modified time: 2017-03-06 01:44:53
*/
#include <ArduinoJson.h>
#include "handle.h"
#include "gpio.h"
#include "wifi.h"
#include "power.h"
#include "log.h"

#define RESP_INVALID() "{\"type\":\"resp\", \"status\": \"invalid\"}"
#define RESP_OK(val) "{\"type\":\"resp\", \"status\": \"ok\", \"result\":"val"}"
AppHandle::AppHandle(): _led(16), _relay(12), _processing(false)
{
	pinMode(_led, OUTPUT);
	pinMode(_relay, OUTPUT);
}
String AppHandle::_invalid(std::function<void(String resp)> cb)
{
	if(cb)
		cb(RESP_INVALID());
	_processing = false;
	return RESP_INVALID();
}
String AppHandle::_ok(String action, String result, std::function<void(String resp)> cb)
{
	String resp = "{\"type\":\"resp\", \"status\": \"ok\", \"action\":\"" + action + "\", \"result\":" + result + "}";
	if(cb)
		cb(resp);
	_processing = false;
	return resp;
}
void AppHandle::setup()
{

}
void AppHandle::processWS(AsyncWebSocket * server, AsyncWebSocketClient * client, AwsEventType type, void * arg, uint8_t *data, size_t len)
{
	AwsFrameInfo * info = (AwsFrameInfo*)arg;


	if(type == WS_EVT_CONNECT) {
		LOG("ws[%s][%u] connect\n", server->url(), client->id());
		client->ping();

	} else if(type == WS_EVT_DISCONNECT) {
		LOG("ws[%s][%u] disconnect: %u\n", server->url(), client->id());
	} else if(type == WS_EVT_ERROR) {
		LOG("ws[%s][%u] error(%u): %s\n", server->url(), client->id(), *((uint16_t*)arg), (char*)data);
	} else if(type == WS_EVT_PONG) {
		LOG("ws[%s][%u] pong[%u]: %s\n", server->url(), client->id(), len, (len) ? (char*)data : "");
	} else if(type == WS_EVT_DATA) {

		String msg = "";
		if(info->final && info->index == 0 && info->len == len) {
			LOG("ws[%s][%u] %s-message[%llu]: ", server->url(), client->id(), (info->opcode == WS_TEXT) ? "text" : "binary", info->len);

			if(info->opcode == WS_TEXT) {
				for(size_t i = 0; i < info->len; i++) {
					msg += (char) data[i];
				}
			} else {
				char buff[3];
				for(size_t i = 0; i < info->len; i++) {
					sprintf(buff, "%02x ", (uint8_t) data[i]);
					msg += buff ;
				}
			}
			LOG("%s\n", msg.c_str());

			process(msg, [client, info](String resp) {
				if(resp == "")
					return;
				if(info->opcode == WS_TEXT)
					client->text(resp);
				else
					client->binary(resp);
			});

		} else {
			//message is comprised of multiple frames or the frame is split into multiple packets
			if(info->index == 0) {
				if(info->num == 0)
					LOG("ws[%s][%u] %s-message start\n", server->url(), client->id(), (info->message_opcode == WS_TEXT) ? "text" : "binary");
				LOG("ws[%s][%u] frame[%u] start[%llu]\n", server->url(), client->id(), info->num, info->len);
			}

			LOG("ws[%s][%u] frame[%u] %s[%llu - %llu]: ", server->url(), client->id(), info->num, (info->message_opcode == WS_TEXT) ? "text" : "binary", info->index, info->index + len);

			if(info->opcode == WS_TEXT) {
				for(size_t i = 0; i < info->len; i++) {
					msg += (char) data[i];
				}
			} else {
				char buff[3];
				for(size_t i = 0; i < info->len; i++) {
					sprintf(buff, "%02x ", (uint8_t) data[i]);
					msg += buff ;
				}
			}
			LOG("%s\n", msg.c_str());

			if((info->index + len) == info->len) {
				LOG("ws[%s][%u] frame[%u] end[%llu]\n", server->url(), client->id(), info->num, info->len);
				if(info->final) {
					LOG("ws[%s][%u] %s-message end\n", server->url(), client->id(), (info->message_opcode == WS_TEXT) ? "text" : "binary");

					process(msg, [client, info](String resp) {
						if(resp == "")
							return;
						if(info->opcode == WS_TEXT)
							client->text(resp);
						else
							client->binary(resp);
					});
				}
			}
		}
	}
}
String AppHandle::process(String msg)
{
	return process(msg, NULL);
}
String AppHandle::process(String msg, std::function<void(String resp)> cb)
{
	DynamicJsonBuffer jsonBuffer(1024);
	JsonObject& json = jsonBuffer.parseObject(msg.c_str());
	String resp = "", action, method;
	AppGPIO gpio;
	AppWIFI wifi;
	AppPOWER power;

	_processing = true;
	if(!json.success()) {
		return _invalid(cb);
	}
	if(json.containsKey("action") && json.containsKey("method")) {
		action = String(json["action"].asString());
		method = String(json["method"].asString());

		//Process action gpio
		if(action == "gpio") {
			if(!json["param"].is<JsonArray&>()) {
				return _invalid(cb);
			}
			JsonArray& allParams =  json["param"];
			if(method == "post")
				return _ok(action, gpio.set(allParams), cb);
			else if(method == "get")
				return _ok(action, gpio.get(allParams), cb);

		}

		//Process action wifi
		if(action == "wifi") {
			if(method == "get") {
				wifi.scan([this, cb, action](String result){
					cb(this->_ok(action, result, NULL));
				});
				return "";
				// return _ok(action, , NULL);
			}
		}

		//Process action get status
		if(action == "power") {
			if(method == "get") {
				return _ok(action, "[1,2,3,4]", NULL);
			}
		}
	}
	return _invalid(cb);
}
void AppHandle::processInterval(AsyncWebSocket * server)
{
	static unsigned long previousMillis = 0;
	unsigned long currentMillis = millis();
	if (currentMillis - previousMillis >= 1000) {
	    // save the last time you blinked the LED
	    previousMillis = currentMillis;
	    server->textAll(process("{\"type\": \"req\", \"action\":\"power\", \"method\": \"get\"}").c_str());
	    Serial.println(process("{\"type\": \"req\", \"action\":\"power\", \"method\": \"get\"}").c_str());
	    // if(resp != "" && server->count() > 0) {
	    // 	server->textAll(resp.c_str());
	    // }
	    // LOG(resp);
	}
}
