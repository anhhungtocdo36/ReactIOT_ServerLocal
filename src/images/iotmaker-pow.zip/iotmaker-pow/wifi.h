#ifndef _APPWIFI_H_
#define _APPWIFI_H_
#include <Arduino.h>
class AppWIFI {
public:
	AppWIFI(): _scanning(false){};
	String scan(std::function<void(String resp)> onComplete);
	void connect(String ssid, String pass);
protected:
	bool _scanning;
};
#endif