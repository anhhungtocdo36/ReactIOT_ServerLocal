#Websocket protocol
## Request
```
{"type": "req", "action":"$ACTION", "method": $METHOD "param": $PARAMS}
```
- $METHOD = 'get' => request data 
- $METHOD = 'post' => add new data 
- $METHOD = 'put' => edit data
### $ACTION
- `gpio`: Control GPIO
    + `$PARAMS`: `[gpionum, gpiovalue]`
    + `{"type": "req", "action":"gpio", "method": "post", "param": [{io: 16, val: 1}]}`
    + Response: `{"type": "resp", "action":"gpio", "status":"ok", result":[{io: 16, val:1}]}`
    + Response invalid:  `{"type": "resp", "action":"gpio", "status":"invalid"}`
- `status`: Load all current status
    + `{"type": "req", "action":"load", "method": "get"}` 
    + Response:
    ```
    {"type": "resp", "action":"status", "status":"ok", "result": {
            "time": unixtimestamp,
            "gpio": [{io: 16, val: 1}],
            "volt": 220,
            "current": 1.2,
            "power": 120
        }
    }
    ```
- `wifi`: Scan or set STA wifi network
    +  `{"type": "req", "action":"wifi", "method": "get"}` Scan wifi 
    +  `{"type": "req", "action":"wifi", "method": "post", "param": {"ssid": "ssid", "password": "password"}}` set wifi ssid & password, password = NULL or not availabe is open wifi network 